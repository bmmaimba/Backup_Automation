## Module <auto_database_backup>
#### 12.02.2024
#### Version 12.0.1.0.0
#### ADD
- Initial commit for Auto Database Backup

#### 16.02.2024
#### Version 12.0.1.0.1
#### ADD
- Dropbox integration added. Backup can be stored in to dropbox.

#### 16.02.2024
#### Version 12.0.1.0.1
#### ADD
- Onedrive integration added. Backup can be stored in to onedrive.

#### 16.02.2024
#### Version 12.0.1.0.1
#### ADD
- Google Drive authentication updated.

#### 16.02.2024
#### Version 12.0.1.0.1
#### ADD
- Nextcloud and Amazon S3 integration added. Backup can be stored into Nextcloud and Amazon S3.
