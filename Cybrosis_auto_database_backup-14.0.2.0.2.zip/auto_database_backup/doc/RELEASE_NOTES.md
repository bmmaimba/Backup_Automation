## Module <auto_database_backup>

#### 20.04.2022
#### Version 14.0.1.0.0
#### ADD
- Initial commit for auto_database_backup

#### 16.02.2024
#### Version 14.0.1.0.1
#### ADD
- Dropbox integration added. Backup can be stored in to dropbox.

#### 16.02.2024
#### Version 14.0.1.0.1
#### ADD
- Onedrive integration added. Backup can be stored in to onedrive.

#### 16.02.2024
#### Version 14.0.1.0.1
#### ADD
- Google Drive authentication updated.

#### 16.02.2024
#### Version 14.0.1.0.1
#### ADD
- Nextcloud and Amazon S3 integration added. Backup can be stored into Nextcloud and Amazon S3.

#### 24.10.2024
#### Version 14.0.2.0.2
#### UPDT
-  Fixed the errors while inputting list_db = False in odoo conf file.
