## Module <auto_database_backup>

#### 06.11.2023
#### Version 17.0.1.0.0
#### ADD

- Initial commit for auto_database_backup

## Module <auto_database_backup>

#### 31.10.2022
#### Version 17.0.2.0.1
#### UPDT

- Updated the database name check function which got access denied when list_db=False.

## Module <auto_database_backup>

#### 18.04.2024
#### Version 17.0.3.0.1
#### UPDT

- Fixed the errors while inputting list_db = False in odoo conf file.

## Module <auto_database_backup>

#### 21.05.2024
#### Version 17.0.4.0.1
#### UPDT

- Changed response.list_buckets() function to head_bucket().

## Module <auto_database_backup>

#### 08.07.2024
#### Version 17.0.5.0.1
#### UPDT

- Fixed the nextcloud auto remove backup error.

## Module <auto_database_backup>

#### 08.07.2024
#### Version 17.0.6.0.1
#### UPDT

- Fixed the windows backup error.
